'use client'

import KahngCPAWebsite from "./site"

export default function Page() {
  return <KahngCPAWebsite />
}
