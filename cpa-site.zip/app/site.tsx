 "use client"

import { useState } from "react"

export default function KahngCPAWebsite() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")

  const [recruitingContent, setRecruitingContent] = useState({
    title: "Join Our Team",
    description:
      "We are always looking for motivated professionals who want to grow in accounting, tax, and advisory services.",
    points: [
      "Work with experienced CPAs and grow your skills.",
      "Hybrid and flexible work options available.",
      "Competitive salary and professional development support.",
    ],
  })

  const [editRecruiting, setEditRecruiting] = useState(recruitingContent)

  const [jobs, setJobs] = useState([
    {
      id: 1,
      title: "Tax Associate",
      type: "Full-Time · Centreville, VA",
      description:
        "Seeking motivated professionals with tax preparation experience.",
    },
    {
      id: 2,
      title: "Accounting Staff",
      type: "Full-Time · Hybrid Available",
      description:
        "Responsible for bookkeeping, payroll support, and accounting services.",
    },
  ])

  const [newJob, setNewJob] = useState({ title: "", type: "", description: "" })

  const handleLogin = () => {
    const u = username.trim().toLowerCase()
    const p = password.trim()

    if (u === "admin" && p === "1234") {
      setIsLoggedIn(true)
    } else {
      alert("Invalid credentials (admin / 1234)")
    }
  }

  const handleLogout = () => setIsLoggedIn(false)

  const addJob = () => {
    if (!newJob.title || !newJob.type || !newJob.description) return
    setJobs([{ id: Date.now(), ...newJob }, ...jobs])
    setNewJob({ title: "", type: "", description: "" })
  }

  const saveRecruiting = () => {
    setRecruitingContent(editRecruiting)
    alert("Saved (local demo)")
  }

  return (
    <div style={{ fontFamily: "sans-serif", padding: 20 }}>
      <h1>Kahng & Associates, CPA</h1>

      <section>
        <h2>{recruitingContent.title}</h2>
        <p>{recruitingContent.description}</p>
        <ul>
          {recruitingContent.points.map((p, i) => (
            <li key={i}>{p}</li>
          ))}
        </ul>
      </section>

      <section>
        <h2>Careers</h2>
        {jobs.map((j) => (
          <div key={j.id}>
            <h3>{j.title}</h3>
            <p>{j.type}</p>
            <p>{j.description}</p>
          </div>
        ))}
      </section>

      {!isLoggedIn && (
        <div>
          <h3>Admin Login</h3>
          <input placeholder="admin" value={username} onChange={(e)=>setUsername(e.target.value)} />
          <input type="password" placeholder="1234" value={password} onChange={(e)=>setPassword(e.target.value)} />
          <button onClick={handleLogin}>Login</button>
        </div>
      )}

      {isLoggedIn && (
        <button onClick={handleLogout}>Logout</button>
      )}
    </div>
  )
}
